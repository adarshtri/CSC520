1. Kindly provide the full path to the author directories.
2. If the code gives an exception, try running it again. Since it picks a random unigram, and then the next word using bigram, there is a possibility that this bigram is not present as a trigram.
3. The model runs fast. It’s the probability file generation that takes time because of formatting. (1min)

